import os
from abcd_converter_gfbio_org.handlers import InOutHandler, DataProvider, Outputter

import sys, os
myPath = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, myPath + '/../')

from abcd_converter_gfbio_org.abcd_conversion import convert_csv_to_abcd

#from ..abcd_converter_gfbio_org.abcd_conversion import convert_csv_to_abcd

class TestDataProvider(DataProvider):
    def __init__(self, datestring):
        self.datestring = datestring

    def get_created_date(self):
        return self.datestring


class TestLogger(Outputter):
    def __init__(self):
        self.log = []

    def handle(self, description, content):
        self.log.append({ "description": description, "content": content })


def test_successfull_conversion_and_validation():
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis.csv')
    result_file = os.path.join(current_path, 'result.xml')

    io_handler = InOutHandler()
    io_handler.dataProvider = TestDataProvider('1994-11-30T00:00:00')

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)
    result = ""
    with open(result_file, 'r') as f:
        result = f.read()

    assert result == xml

def test_failing_validation():
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis.csv')

    io_handler = InOutHandler()
    io_handler.dataProvider = TestDataProvider('ErRoR, DiS hAs 2B a D8')
    io_handler.errorHandler = TestLogger()

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)

    assert xml == None
    assert len(io_handler.errorHandler.log) == 1
    print(io_handler.errorHandler.log[0]["description"])
    assert io_handler.errorHandler.log[0]["description"] == "failed validating 'ErRoR, DiS hAs 2B a D8' with XsdAtomicBuiltin(name='xs:dateTime'): Invalid datetime string 'ErRoR, DiS hAs 2B a D8' for <class 'elementpath.datatypes.datetime.DateTime10'> (/DataSets/DataSet/Metadata/RevisionData/DateModified)"