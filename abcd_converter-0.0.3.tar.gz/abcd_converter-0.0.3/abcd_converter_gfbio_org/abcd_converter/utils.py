import re
import csv

def create_csv_reader(csv_file):
    header = csv_file.readline()
    dialect = csv.Sniffer().sniff(header)
    csv_file.seek(0)
    delimiter = dialect.delimiter if dialect.delimiter in [",", ";", "\t"] else ";"
    # read the csv data from file:
    csv_reader = csv.DictReader(
        csv_file,
        quoting=csv.QUOTE_ALL,
        delimiter=delimiter,
        quotechar='"',
        skipinitialspace=True,
        restkey="extra_columns_found",
        restval="extra_value_found",
    )
    return csv_reader


def xsplit(delimiters, string, maxsplit=0):
    regex_pattern = "|".join(map(re.escape, delimiters))
    return re.split(regex_pattern, string, maxsplit)