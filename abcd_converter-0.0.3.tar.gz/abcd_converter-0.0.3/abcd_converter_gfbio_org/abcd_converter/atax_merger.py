import xml.etree.ElementTree as ET

def find_node_in_root(nodes_root, nodes_name):
    posi = -1
    found = False
    for child in nodes_root:
        posi = posi + 1
        if str(child.tag).endswith(nodes_name):
            found = True
            break
    return found, posi


def update_specimen_with_measurements_abcd_xml(to_add_to, to_add):
    # do this, if both specimen nd measurements are there:
    # roots for both xml constructs:
    tree_spec_root = ET.fromstring(to_add_to)
    tree_meas_root = ET.fromstring(to_add)

    ET.register_namespace("abcd", "http://www.tdwg.org/schemas/abcd/2.06")

    result = {}
    meas_keys_found = []

    meas_units_root = tree_meas_root.find(".//{http://www.tdwg.org/schemas/abcd/2.06}Units")  # list of elements 
    
    # this should work with whole tree_meas_root too instead of subelement units_root!
    meas_units = meas_units_root.findall(".//{http://www.tdwg.org/schemas/abcd/2.06}Unit")  # list of elements

    # create dictionary for UnitID, MeasurementOrFacts  xml string
    for meas_unit in meas_units:
        unitid = meas_unit.find(".//{http://www.tdwg.org/schemas/abcd/2.06}UnitID")  # Element
        measorfacts = meas_unit.find(
            ".//{http://www.tdwg.org/schemas/abcd/2.06}MeasurementsOrFacts"
        )  # Element
        unitid_content = unitid.text
        result[unitid_content] = measorfacts

    # insert  MeasurementOrFacts into specimen part:
    for unit_spec in tree_spec_root.findall(".//{http://www.tdwg.org/schemas/abcd/2.06}Unit"):
        #  for removing MeasurementsOrFacts,for updates also:
        elem_facts = unit_spec.find(".//{http://www.tdwg.org/schemas/abcd/2.06}MeasurementsOrFacts")
        if elem_facts is not None:
            unit_spec.remove(unit_spec.find(".//{http://www.tdwg.org/schemas/abcd/2.06}MeasurementsOrFacts"))

        found, pos = find_node_in_root(unit_spec, "Sex")
        unitidstr = str(unit_spec.find(".//{http://www.tdwg.org/schemas/abcd/2.06}UnitID").text)

        if unitidstr in result.keys() and result[unitidstr]:
            # as return value only:
            meas_keys_found.append(unitidstr)

            if found:
                unit_spec.insert(pos, result[unitidstr])
            else:
                unit_spec.append(result[unitidstr])  # element append measurements

    res_after_insert = ET.tostring(tree_spec_root, encoding="unicode", method="xml")

    return res_after_insert


def update_specimen_with_multimedia_abcd_xml(to_add_to, to_add):
    # basis:
    tree_spec_root = ET.fromstring(to_add_to)
    tree_mult_root = ET.fromstring(to_add)

    ET.register_namespace("abcd", "http://www.tdwg.org/schemas/abcd/2.06")

    result = {}
    multi_keys_found = []

    # units is there max 1x:
    mult_units_collection = tree_mult_root.find(".//{http://www.tdwg.org/schemas/abcd/2.06}Units")
    mult_units = mult_units_collection.findall(".//{http://www.tdwg.org/schemas/abcd/2.06}Unit")  # list of elements

    # create dictionary for UnitID, MultimediaObjects  xml string
    for unit_mult in mult_units:

        unitid = unit_mult.find(".//{http://www.tdwg.org/schemas/abcd/2.06}UnitID")  # Element
        multis = unit_mult.find(".//{http://www.tdwg.org/schemas/abcd/2.06}MultiMediaObjects")  # Element
        unitid_content = unitid.text
        result[unitid_content] = multis

    # insert  MultimediaObjects into specimen part:
    for unit_spec in tree_spec_root.findall(".//{http://www.tdwg.org/schemas/abcd/2.06}Unit"):
        elem_multis = unit_spec.find(".//{http://www.tdwg.org/schemas/abcd/2.06}MultiMediaObjects")
        if elem_multis is not None:
            unit_spec.remove(unit_spec.find(".//{http://www.tdwg.org/schemas/abcd/2.06}MultiMediaObjects"))

        unitidstr = str(unit_spec.find(".//{http://www.tdwg.org/schemas/abcd/2.06}UnitID").text)

        found, pos = find_node_in_root(unit_spec, "Gathering")

        if unitidstr in result.keys():
            multi_keys_found.append(unitidstr)

            if found:
                unit_spec.insert(pos, result[unitidstr])
            else:
                unit_spec.append(result[unitidstr])

    res_after_insert = ET.tostring(tree_spec_root, encoding="unicode", method="xml")

    return res_after_insert
