# -*- coding: utf-8 -*-
import logging

from .atax_merger import (
    update_specimen_with_measurements_abcd_xml,
    update_specimen_with_multimedia_abcd_xml,
)
logger = logging.getLogger(__name__)

def atax_submission_combine_xmls_to_one_structure_task(
    specimen_xml, measurement_xml, multimedia_xml
    
):    
    combination_xml = update_specimen_with_measurements_abcd_xml(specimen_xml, measurement_xml)
    combination_xml = update_specimen_with_multimedia_abcd_xml(combination_xml, multimedia_xml)
    return combination_xml
