# -*- coding: utf-8 -*-
import logging

from .schema_validation import validate_atax_data_is_valid


def atax_submission_validate_auditable_atax_xml_task(
    text_to_validate, io_handler
):
    errors = validate_atax_data_is_valid(
        text_to_validate,  # string_abcd_xml_converted,
        io_handler
    )

    if errors:
        return False
    else:
        return True


def atax_submission_validate_xml_upload_task(
    self,
    submission_upload,
    is_combination=False,
):
    if not is_combination:
        # simple upload file name:
        upload_name = submission_upload.file.name.split("/")[-1:][0]

        # get the stored xml string back from auditabletextdata:
        text_to_validate = ""
        if len(submission_upload.submission.auditabletextdata_set.filter(atax_file_name=upload_name)):
            upload_by_file__name = submission_upload.submission.auditabletextdata_set.filter(
                atax_file_name=upload_name
            ).first()
    elif is_combination:
        upload_by_file__name = submission_upload.submission.auditabletextdata_set.filter(name="combination").first()

    if upload_by_file__name is not None:
        text_to_validate = upload_by_file__name.text_data

        errors = validate_atax_data_is_valid(
            submission=submission_upload.submission,
            xml_string=text_to_validate,  # string_abcd_xml_converted
        )
        # if abcd xml not valid:
        if errors:
            messages = [e.message for e in errors]
            print(messages)

        else:
            submission_upload.submission.save()

            # update field atax_xml_valid:
            if upload_by_file__name is not None:
                upload_by_file__name.atax_xml_valid = True
                upload_by_file__name.save()

            return {"is_valid": upload_by_file__name.atax_xml_valid}  # text_to_validate

    else:
        return True
