import argparse
from .abcd_conversion import convert_csv_to_abcd
from .handlers import InOutHandler

def main():
    print("Running abcd-conversion")

    parser = argparse.ArgumentParser()

    #parser.add_argument("--info_file", "-i", type=str, required=True)
    parser.add_argument("--measurement_file", "-m", type=str, required=True)
    parser.add_argument("--specimen_file", "-s", type=str, required=True)
    parser.add_argument("--multimedia_file", "-x", type=str, required=True)
    parser.add_argument("--out", "-o", type=str, required=False)
    parser.add_argument("--verbose", "-v", required=False, action='store_true')
    args = parser.parse_args()

    out_file = args.out
    out_file = out_file if out_file else "result.xml"

    convert_csv_to_abcd(args.specimen_file, args.measurement_file, args.multimedia_file, InOutHandler(args.verbose, out_file))


if __name__ == '__main__':
    main()