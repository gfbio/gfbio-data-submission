from .handlers import InOutHandler

from .abcd_converter.atax_submission_parse_csv_upload_to_xml import convert_specimen_file, convert_measurement_file, convert_multimedia_file
from .abcd_converter.atax_submission_combine_xmls_to_one_structure import atax_submission_combine_xmls_to_one_structure_task
from .abcd_converter.atax_submission_validate_xml_upload import atax_submission_validate_auditable_atax_xml_task


def convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler = InOutHandler()):

    spec_xml = convert_specimen_file(specimen_file, io_handler)
    meas_xml = convert_measurement_file(measurement_file, io_handler)
    multi_xml = convert_multimedia_file(multimedia_file, io_handler)


    combi_xml = atax_submission_combine_xmls_to_one_structure_task(spec_xml, meas_xml, multi_xml)
    io_handler.resultFileHandler.handle("Generation of abcd completed.", combi_xml)

    is_valid = atax_submission_validate_auditable_atax_xml_task(combi_xml, io_handler)
    if is_valid:
        return combi_xml