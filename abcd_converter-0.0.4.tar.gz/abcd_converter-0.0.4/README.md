# ABCD Converter

## Abstract
The ABCD Converter can be sued to convert and validate specimen data from several input CSVs to a single ABCD 2.06 file.
You can either use it as a command line tool or import it into your python-project.

## For Users

### How to install
To install the package from our registry just execute
```
pip install abcd-converter --index-url https://gitlab-pe.gwdg.de/api/v4/projects/26166/packages/pypi/simple
```

### How to run
This project requires python to be installed on your machine.
To directly convert the CSVs to the ABCD-XML just install the package via pip on your PC and open your command-line.
Then execute the converter (recommended is in the same folder as the csv-files) and setting the files according to their content and optionally the file to write the output to. If no output file is specified the output will end up in the current directory in the file result.xml.
To run the converter execute
```
python -m abcd_converter_gfbio_org --measurement_file measurement_table.csv -specimen_file specimen_table.csv --multimedia_file multimedia_table.csv --multimedia_folder ./ --out result_name.xml
```

or in short
```
python -m abcd_converter_gfbio_org -m measurement_table.csv -s specimen_table.csv -x multimedia_table.csv -f ./ -o result_name.xml
```

Also you can of course get the documentation in the console with
```
python -m abcd_converter_gfbio_org --help
```

#### On Windows
If installed correctly you should also be able to run the converter as a standalone program with:
```
abcd_converter.exe -m measurement_table.csv -s specimen_table.csv -x multimedia_table.csv -f ./ -o result_name.xml
```


### Simple sample
To have a simple testrun to check if everything is installed correctly and to get a feeling on how to use the converter, follow these steps
1. Install the converter according to the above section
2. Download from this repository the directory /tests/sample_data
3. Open your terminal in the downloaded directory
4. Run `python -m abcd_converter_gfbio_org -m measurement_table_Platypelis.csv -s specimen_table_Platypelis.csv -x multimedia_table_Platypelis.csv --skip_multimediafile_validation -o ABCD_Platypelis.xml`

## For Developers
### Use in python project
To use the converter in a project install the package abcd_converter_gfbio_org with a the command in the how-to-install-section.
To just use it out of the box use `from abcd_converter_gfbio_org.abcd_conversion import convert_csv_to_abcd` in your python file.
Then call `convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)` and it will return the abcd-xml as text, already verified against the abcd-schema.
Per default validation-errors are just printed out to the console. To handle them customly just overwrite the handlers of the `io_handler`-object.

### Testing
To run the tests, execute `pytest tests` in the root-folder of the project.

### Build
To build the package just execute `python -m build` in the main-directory.
To upload the file to the gitlab-repository use `TWINE_PASSWORD={{access-token-pass}} TWINE_USERNAME={{access-token-name}} python3 -m twine upload --repository-url https://gitlab-pe.gwdg.de/api/v4/projects/26166/packages/pypi dist/*`.
Don't forget to update the version in the setup.cfg before building/uploading.



## Support
If you encounter any issues or need help, get in touch with [info@gfbio.org].

## Authors and acknowledgment
This work was financed by the German Research Foundation (DFG) through the project "Concepts, tools and support for managing, archiving, mobilizing and integrating taxonomic data in the framework of SPP 1991" (Project Nr.: [447018505](https://gepris.dfg.de/gepris/projekt/447018505)), within the Priority Programme [Taxon-Omics](https://www.taxon-omics.com/) (project Nr.: [313688472](https://gepris.dfg.de/gepris/projekt/313688472)) .

## License
See LICENSE file in this repository.