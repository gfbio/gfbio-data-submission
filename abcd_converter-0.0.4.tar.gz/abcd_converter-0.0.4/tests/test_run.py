import os
from abcd_converter_gfbio_org.file_validation import MultimediaFileValidatorInterface
from abcd_converter_gfbio_org.handlers import InOutHandler, DataProvider, Outputter

import sys, os
myPath = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, myPath + '/../')

from abcd_converter_gfbio_org.abcd_conversion import convert_csv_to_abcd

#from ..abcd_converter_gfbio_org.abcd_conversion import convert_csv_to_abcd

class TestDataProvider(DataProvider):
    def __init__(self, datestring):
        self.datestring = datestring

    def get_created_date(self):
        return self.datestring


class TestLogger(Outputter):
    def __init__(self):
        self.log = []

    def handle(self, description, content):
        self.log.append({ "description": description, "content": content })


def test_successfull_conversion_and_validation():
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis.csv')
    result_file = os.path.join(current_path, 'result.xml')

    io_handler = InOutHandler()
    io_handler.dataProvider = TestDataProvider('1994-11-30T00:00:00')
    io_handler.resultFileHandler = Outputter()
    io_handler.errorHandler = Outputter()
    io_handler.logHandler = Outputter()
    io_handler.singleFileHandler = Outputter()
    io_handler.multimedia_validator = MultimediaFileValidatorInterface()

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)
    result = ""
    with open(result_file, 'r', encoding="utf-8-sig") as f:
        result = f.read()

    assert result == xml


def test_failing_validation():
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis.csv')
    test_logger = TestLogger()

    io_handler = InOutHandler()
    io_handler.dataProvider = TestDataProvider('ErRoR, DiS hAs 2B a D8')
    io_handler.resultFileHandler = Outputter()
    io_handler.logHandler = Outputter()
    io_handler.singleFileHandler = Outputter()
    io_handler.multimedia_validator = MultimediaFileValidatorInterface()
    io_handler.errorHandler = test_logger

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)

    assert xml == None
    assert len(test_logger.log) == 2
    assert test_logger.log[0]["description"] == "failed validating 'ErRoR, DiS hAs 2B a D8' with XsdAtomicBuiltin(name='xs:dateTime'): Invalid datetime string 'ErRoR, DiS hAs 2B a D8' for <class 'elementpath.datatypes.datetime.DateTime10'> (/DataSets/DataSet/Metadata/RevisionData/DateModified)"


def test_error_on_duplicate_unit_ids():
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis_duplicate_submission_ids.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis.csv')
    test_error_logger = TestLogger()

    io_handler = InOutHandler()
    io_handler.multimedia_validator = MultimediaFileValidatorInterface()
    io_handler.dataProvider = TestDataProvider('1994-11-30T00:00:00')
    io_handler.errorHandler = test_error_logger

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)
    
    assert xml == None
    assert len(test_error_logger.log) == 2
    assert test_error_logger.log[0]["description"] == "Unit-ids must be unique among specimen."
    assert test_error_logger.log[0]["content"]["message"] == "Repeating unit-ids: \nZSM 5655/2012 in rows 2, 8"
    assert test_error_logger.log[1]["description"] == "Process ran into (validation-)errors. Please check error-log for further information."


def test_error_on_file_not_found():    
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis.csv')
    error_logger = TestLogger()

    io_handler = InOutHandler()
    io_handler.errorHandler = error_logger

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)

    assert len(error_logger.log) == 15
    assert error_logger.log[0]["description"] == "File FGZC 3588.jpg in row 2 is missing it's corresponding file './FGZC 3588.jpg'."


def test_no_error_on_file_found():    
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_test_file.csv')
    error_logger = TestLogger()

    io_handler = InOutHandler(file_directory="tests/sample_data/")
    io_handler.errorHandler = error_logger

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)

    assert xml
    assert len(error_logger.log) == 0


def test_warning_on_file_format_missmatch():    
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_test_file_wrong_format.csv')
    error_logger = TestLogger()
    warning_logger = TestLogger()

    io_handler = InOutHandler(file_directory="tests/sample_data/")
    io_handler.errorHandler = error_logger
    io_handler.warning_handler = warning_logger

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)

    assert xml
    assert len(error_logger.log) == 0
    assert len(warning_logger.log) == 1
    assert warning_logger.log[0]["description"] == "File extension 'JPG' of test_image.JPG may not match the format description 'Video'."


def test_error_on_invalid_country():
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis_unknown_country.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis.csv')
    test_error_logger = TestLogger()

    io_handler = InOutHandler()
    io_handler.dataProvider = TestDataProvider('1994-11-30T00:00:00')
    io_handler.multimedia_validator = MultimediaFileValidatorInterface()
    io_handler.errorHandler = test_error_logger

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)
    
    assert xml == None
    assert len(test_error_logger.log) == 2
    assert test_error_logger.log[0]["description"] == "Lummerland in line 6 is not a name of a country or area in the list of acceptable country and area names."
    assert test_error_logger.log[0]["content"]["row"] == 6
    assert test_error_logger.log[0]["content"]["file"] == "specimen"
    assert test_error_logger.log[1]["description"] == "Process ran into (validation-)errors. Please check error-log for further information."


def test_error_on_no_country():
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis_empty_country.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis.csv')
    test_error_logger = TestLogger()

    io_handler = InOutHandler()
    io_handler.dataProvider = TestDataProvider('1994-11-30T00:00:00')
    io_handler.multimedia_validator = MultimediaFileValidatorInterface()
    io_handler.errorHandler = test_error_logger

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)
    
    assert xml == None
    assert len(test_error_logger.log) == 3
    assert test_error_logger.log[0]["description"] == "Line 8 is missing the country."
    assert test_error_logger.log[0]["content"]["row"] == 8
    assert test_error_logger.log[0]["content"]["file"] == "specimen"
    assert test_error_logger.log[1]["description"] == "failed validating '' with XsdMinLengthFacet(value=1, fixed=False): value length cannot be lesser than 1 (/DataSets/DataSet/Units/Unit[8]/Gathering/Country/Name)"
    assert test_error_logger.log[2]["description"] == "Process ran into (validation-)errors. Please check error-log for further information."


def test_error_on_no_matching_specimen():
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis_with_orphan.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis_with_orphan.csv')
    test_error_logger = TestLogger()

    io_handler = InOutHandler()
    io_handler.dataProvider = TestDataProvider('1994-11-30T00:00:00')
    io_handler.multimedia_validator = MultimediaFileValidatorInterface()
    io_handler.errorHandler = test_error_logger

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)

    assert xml == None
    assert len(test_error_logger.log) == 3
    assert test_error_logger.log[0]["description"] == "Measurements for unit-id ZSM 5565/2012 have no corresponding specimen."
    assert test_error_logger.log[1]["description"] == "MultimediaObjects for unit-id ZSM 5565/2012 have no corresponding specimen."
    assert test_error_logger.log[2]["description"] == "Process ran into (validation-)errors. Please check error-log for further information."


def test_with_vaucher_format():
    current_path = os.path.join(os.path.dirname(__file__), "sample_data")
    specimen_file = os.path.join(current_path, 'specimen_table_Platypelis_with_vauchers.csv')
    measurement_file = os.path.join(current_path, 'measurement_table_Platypelis.csv')
    multimedia_file = os.path.join(current_path, 'multimedia_table_Platypelis.csv')
    test_error_logger = TestLogger()
    test_warning_logger = TestLogger()

    io_handler = InOutHandler()
    io_handler.dataProvider = TestDataProvider('1994-11-30T00:00:00')
    io_handler.multimedia_validator = MultimediaFileValidatorInterface()
    io_handler.errorHandler = test_error_logger
    io_handler.warning_handler = test_warning_logger

    xml = convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler)
    
    assert xml
    assert len(test_error_logger.log) == 0
    assert len(test_warning_logger.log) == 3
    assert test_warning_logger.log[0]["description"] == "Unit id 'inval:acssx' does not match voucher structure: 'inval' is not a known institution"
    assert test_warning_logger.log[0]["content"]["message"] == "Unit id does not match voucher structure: 'inval' is not a known institution"
    assert test_warning_logger.log[0]["content"]["row"] == 11
    assert test_warning_logger.log[0]["content"]["file"] == "specimen"
    assert test_warning_logger.log[1]["description"] == "Unit id 'AAABC:BBA:100' does not match voucher structure: 'AAABC' is not a known institution, 'BBA' is not a known collection"
    assert test_warning_logger.log[1]["content"]["row"] == 13
    assert test_warning_logger.log[2]["description"] == "Unit id 'CAT:AAA:321' does not match voucher structure: 'AAA' is not a known collection"
    assert test_warning_logger.log[2]["content"]["row"] == 14