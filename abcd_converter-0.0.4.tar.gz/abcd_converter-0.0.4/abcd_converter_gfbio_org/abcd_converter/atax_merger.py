import xml.etree.ElementTree as ET

abcd_schema_url = "http://www.tdwg.org/schemas/abcd/2.06"
abcdns = f"{{{abcd_schema_url}}}"

def find_node_in_root(nodes_root, nodes_name):
    posi = -1
    found = False
    for child in nodes_root:
        posi = posi + 1
        if str(child.tag).endswith(nodes_name):
            found = True
            break
    return found, posi


class AtaxMerger():
    def __init__(self, io_handler):
        self.io_handler = io_handler


    def update_specimen_with_measurements_abcd_xml(self, to_add_to, to_add):
        tree_to_add_to = ET.fromstring(to_add_to)
        tree_to_add = ET.fromstring(to_add)

        ET.register_namespace("abcd", abcd_schema_url)

        result = {}
        meas_keys_found = []

        meas_units_from = tree_to_add.find(f".//{abcdns}Units")
        meas_units = meas_units_from.findall(f".//{abcdns}Unit")

        for meas_unit in meas_units:
            unitid = meas_unit.find(f".//{abcdns}UnitID")
            measorfacts = meas_unit.find(
                f".//{abcdns}MeasurementsOrFacts"
            )
            unitid_content = unitid.text
            if unitid_content not in result:
                result[unitid_content] = measorfacts
            else:
                for fact in measorfacts.findall(f".//{abcdns}MeasurementOrFact"):
                    result[unitid_content].append(fact)

        # insert MeasurementOrFacts into specimen part:
        for unit_spec in tree_to_add_to.findall(f".//{abcdns}Unit"):
            elem_facts = unit_spec.find(f".//{abcdns}MeasurementsOrFacts")
            if elem_facts is not None:
                unit_spec.remove(elem_facts)

            found, pos = find_node_in_root(unit_spec, "Sex")
            unitidstr = str(unit_spec.find(f".//{abcdns}UnitID").text)

            if unitidstr in result.keys() and result[unitidstr]:
                meas_keys_found.append(unitidstr)

                if found:
                    unit_spec.insert(pos, result[unitidstr])
                else:
                    unit_spec.append(result[unitidstr])
        
        for unitidstr in result.keys():
            if not unitidstr in meas_keys_found:
                self.io_handler.errorHandler.handle(
                    f"Measurements for unit-id {unitidstr} have no corresponding specimen.",
                    {"file": "Measurement", "id": unitidstr, "message": "No corresponding specimen."}
                )

        res_after_insert = ET.tostring(tree_to_add_to, encoding="unicode", method="xml")

        return res_after_insert


    def update_specimen_with_multimedia_abcd_xml(self, to_add_to, to_add):
        tree_to_add_to = ET.fromstring(to_add_to)
        tree_to_add = ET.fromstring(to_add)

        ET.register_namespace("abcd", abcd_schema_url)

        result = {}
        multi_keys_found = []

        mult_units_collection = tree_to_add.find(f".//{abcdns}Units")
        mult_units = mult_units_collection.findall(f".//{abcdns}Unit")

        for unit_mult in mult_units:
            unitid = unit_mult.find(f".//{abcdns}UnitID")
            multis = unit_mult.find(f".//{abcdns}MultiMediaObjects")
            unitid_content = unitid.text
            result[unitid_content] = multis

        # insert  MultimediaObjects into specimen part:
        for unit_spec in tree_to_add_to.findall(f".//{abcdns}Unit"):
            elem_multis = unit_spec.find(f".//{abcdns}MultiMediaObjects")
            if elem_multis is not None:
                unit_spec.remove(unit_spec.find(f".//{abcdns}MultiMediaObjects"))

            unitidstr = str(unit_spec.find(f".//{abcdns}UnitID").text)

            found, pos = find_node_in_root(unit_spec, "Gathering")

            if unitidstr in result.keys():
                multi_keys_found.append(unitidstr)

                if found:
                    unit_spec.insert(pos, result[unitidstr])
                else:
                    unit_spec.append(result[unitidstr])
                
        for unitidstr in result.keys():
            if not unitidstr in multi_keys_found:
                self.io_handler.errorHandler.handle(
                    f"MultimediaObjects for unit-id {unitidstr} have no corresponding specimen.",
                    {"file": "Multimedia", "id": unitidstr, "message": "No corresponding specimen."}
                )

        res_after_insert = ET.tostring(tree_to_add_to, encoding="unicode", method="xml")

        return res_after_insert
