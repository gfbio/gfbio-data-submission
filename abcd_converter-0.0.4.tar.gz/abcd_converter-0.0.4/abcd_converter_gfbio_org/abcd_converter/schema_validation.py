# -*- coding: utf-8 -*-
import datetime
import logging

from .atax_validation_error import AtaxValidationError
import xml.etree.ElementTree as ET

from .atax import Ataxer

from pkg_resources import resource_filename
import xmlschema
    
logger = logging.getLogger(__name__)


def collect_errors(data, validator):
    return [
        "Error(s) regarding field '{0}' because: {1}".format(
            error.relative_path.pop(), error.message.replace("u'", "'")
        )
        if len(error.relative_path) > 0
        else "{0}".format(error.message.replace("u'", "'"))
        for error in validator.iter_errors(data)
    ]


def collect_validation_errors(data, validator):
    return [
        AtaxValidationError(
            "{} : {}".format(
                error.relative_path.pop() if len(error.relative_path) else "",
                error.message.replace("u'", "'"),
            )
        )
        for error in validator.iter_errors(data)
    ]


def collect_validation_xml_errors(data, validator, io_handler):
    errors = []
    for error in validator.iter_errors(data):
        error_path = error._path.replace("{http://www.tdwg.org/schemas/abcd/2.06}", "")
        message = f"{error.message}: {error.reason} ({error_path})"
        io_handler.errorHandler.handle(message, {"file": "result", "message": "Error in abcd-validation", "error": error})
        errors.append(error)
    return errors


def validate_ena_relations(data):
    errors = []
    sample_aliases = [s.get("sample_alias", "") for s in data.get("requirements", {}).get("samples", [])]

    experiment_aliases = [e.get("experiment_alias", "") for e in data.get("requirements", {}).get("experiments", [])]

    experiment_sample_descriptors = [
        e.get("design", {}).get("sample_descriptor", "") for e in data.get("requirements", {}).get("experiments", [])
    ]

    run_experiment_refs = [r.get("experiment_ref") for r in data.get("requirements", {}).get("runs", [])]

    for e in experiment_sample_descriptors:
        if e not in sample_aliases:
            errors.append(
                AtaxValidationError(
                    'experiment: sample_descriptor "{}" in '
                    "experiment does not match any sample_alias "
                    "defined in samples".format(e)
                )
            )

    for r in run_experiment_refs:
        if r not in experiment_aliases:
            errors.append(
                AtaxValidationError(
                    'run: experiment_ref "{}" in run does not '
                    "match any experiment_alias defined in "
                    "experiments".format(e)
                )
            )
    return errors


def validate_atax_data_is_valid(xml_string, io_handler):
    xml_string_valid = False
    
    file_path = resource_filename(__name__, 'ABCD_2.06.XSD')
    schema = xmlschema.XMLSchema(file_path)
    errors = []

    if xml_string:
        tree = ET.ElementTree(ET.fromstring(xml_string))

        xml_string_valid = schema.is_valid(tree)
        if xml_string_valid:
            io_handler.logHandler.handle("Validation against abcd-schema was successfull.", None)
        else:
            io_handler.logHandler.handle("Errors on validating against abcd-schema.", None)
            errors = collect_validation_xml_errors(tree, schema, io_handler)

    return errors


def validate_contributors(data):
    try:
        contributors = data["requirements"]["contributors"]
    except KeyError:
        contributors = None
    if contributors:
        for contributor in contributors:
            for key in contributor:
                value = "{}".format(contributor[key])
                if "|" in value:
                    return False, 'Contributors: pipe "|" character is not allowed'
    return True, ""


def validate_embargo(embargo):
    # check if date is between tomorrow and 2 years from now
    earliest_embargo_date = datetime.date.today() + datetime.timedelta(days=1)
    latest_embargo_date = datetime.date(
        datetime.date.today().year + 2,
        datetime.date.today().month,
        datetime.date.today().day,
    )
    if embargo < earliest_embargo_date:
        return False, "Embargo : earliest possible date is 24 hours from today"
    elif embargo > latest_embargo_date:
        return False, "Embargo : latest possible date is 2 years from today"

    return True, ""
