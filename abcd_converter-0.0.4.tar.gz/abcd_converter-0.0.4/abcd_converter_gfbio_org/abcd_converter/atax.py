import xml.etree.ElementTree as ET
from xml.etree.ElementTree import Element
import traceback

from .utils import create_csv_reader, xsplit

from .csv_atax import (
    add_data_set,
    add_technical_contacts,
    add_content_contacts,
    add_meta_data,
    add_units,
    add_unit,
    add_unit_data_measurement,
    is_float,
    add_unit_id,
    add_necc_nodes_measurements,
    add_measurements_or_facts,
    multimedia_csv_ataxer,
    specimen_csv_ataxer,
)

from .mappings import abcd_mapping_specimen, abcd_mapping_measurement, abcd_mapping_multimedia

global_schema = None


#  ATAXER  base xml for atax -------------------------------------------------------
class Ataxer(object):
    # constructor

    def __init__(self, io_handler):
        self.io_handler = io_handler

        self.schema = "global_schema"

        # namespaces:
        self.xsi = "http://www.w3.org/2001/XMLSchema-instance"
        self.abcd = "http://www.tdwg.org/schemas/abcd/2.06"
        self.schemaLocation = (
            " http://www.tdwg.org/schemas/abcd/2.06 http://www.bgbm.org/TDWG/CODATA/Schema/ABCD_2.06/ABCD_2.06.XSD"
        )

        self.ns = {"xsi": self.xsi, "abcd": self.abcd}  # namespaces
        ET.register_namespace("abcd", "http://www.tdwg.org/schemas/abcd/2.06")
        self.abcdns = "{" + self.abcd + "}"  # namespace abcd for creating Elements

        self.root = Element(
            "{http://www.tdwg.org/schemas/abcd/2.06}DataSets",
            attrib={"{" + self.xsi + "}schemaLocation": self.schemaLocation},
        )

    def map_fields_specimen(self, csv_dict, abcd_dict, result_dict=None):
        import datetime

        month = 1
        day = 1

        time_keys1 = ["date: day"]
        time_keys2 = ["date: month"]
        time_keys3 = ["date: year"]
        time_mapped = ["IsoDateTimeBegin"]
        
        unknowns = ["none", "nan", "unknown", "null", "empty"]

        result_dict = result_dict or {}
        csv_dict = {k.strip().lower(): v for k, v in csv_dict.items()}
        for k, v in csv_dict.items():
            if isinstance(v, dict):
                v = self.map_fields_specimen(v, abcd_dict)
            if k in abcd_dict.keys():
                if k in time_keys3:
                    year = str(v)
                    if year and month and day and not year.strip().lower() in unknowns and not month.strip().lower() in unknowns and not day.strip().lower() in unknowns:
                        dtobj = datetime.datetime(int(year), int(month), int(day))
                        dtstr = dtobj.strftime("%Y-%m-%d")  # should be a string
                        result_dict["IsoDateTimeBegin"] = dtstr
                elif k in time_keys2:
                    month = str(v)
                elif k in time_keys1:
                    day = str(v)
                k = str(abcd_dict[k])  # key will be changed
            if k not in time_mapped:
                result_dict[k] = v
        return result_dict

    def map_fields_measurement(self, csv_dict, abcd_dict, result_dict=None):
        import datetime

        month = 1
        day = 1
        time = "00:00"

        time_keys0 = ["time"]
        time_keys1 = ["date: day"]
        time_keys2 = ["date: month"]
        time_keys3 = ["date: year"]
        time_mapped = [
            "MeasurementDateTime",
        ]
        crea_date = True
        unknowns = ["none", "nan", "unknown", "null", "empty"]

        result_dict = result_dict or {}
        csv_dict = {k.strip().lower(): v for k, v in csv_dict.items()}
        for k, v in csv_dict.items():
            if isinstance(v, dict):
                v = self.map_fields_measurement(v, abcd_dict)
            if k in abcd_dict.keys():
                if k in time_keys3:
                    if len(v) and v.strip().lower() not in unknowns and crea_date == True:
                        year = str(v)
                        if time:
                            dtobj = datetime.datetime(
                                int(year),
                                int(month),
                                int(day),
                                int(time.hour),
                                int(time.minute),
                            )
                            dtstr = dtobj.strftime("%Y-%m-%dT%H:%M:%S")  # should be a string
                        else:
                            dtobj = datetime.datetime(int(year), int(month), int(day), 0, 0)
                            dtstr = dtobj.strftime("%Y-%m-%dT%H:%M:%S")  # should be a string
                        result_dict["MeasurementDateTime"] = dtstr
                    else:
                        crea_date = False
                elif k in time_keys2:
                    if len(v) and v.strip().lower() not in unknowns:
                        month = str(v)
                    else:
                        crea_date = False
                elif k in time_keys1:
                    if len(v) and v.strip().lower() not in unknowns:
                        day = str(v)
                    else:
                        crea_date = False
                elif k in time_keys0:
                    if len(v) and v.strip().lower() not in unknowns:
                        time = datetime.datetime.strptime(v, "%H:%M")  # time.hour, time.minut
                    else:
                        time = None

                k = str(abcd_dict[k])  # key is changed
            if (time_mapped.count(str(k)) == 0) and len(v) and v.strip().lower() not in unknowns:
                result_dict[k] = v
        return result_dict

    def map_fields_multimedia(self, csv_dict, abcd_dict, result_dict=None):
        result_dict = result_dict or {}
        csv_dict = {k.strip().lower(): v for k, v in csv_dict.items()}
        for k, v in csv_dict.items():
            if isinstance(v, dict):
                v = self.map_fields_multimedia(v, abcd_dict)
            if k in abcd_dict.keys():
                k = str(abcd_dict[k])  # key will be changed
            result_dict[k] = v
        return result_dict

    def create_atax_submission_base_xml(self):
        dataset = add_data_set(self.root, self.abcdns)

        # add necessary abcd nodes:
        add_technical_contacts(dataset, self.abcdns, self.io_handler.dataProvider)

        add_content_contacts(dataset, self.abcdns, self.io_handler.dataProvider)
        add_meta_data(
            dataset,
            self.abcdns,
            self.io_handler.dataProvider,
        )
        units = add_units(dataset, self.abcdns)

        return units

    def read_and_map_specimen_csv(self, csv_file):
        # map the csv fields to abcd terms:
        csv_data = []
        csv_data_p = list(create_csv_reader(csv_file))
        for rowdict in csv_data_p:
            row = self.map_fields_specimen(rowdict, abcd_mapping_specimen)
            csv_data.append(row)

        return csv_data

    def read_and_map_measurement_csv(self, csv_file):
        known_tags = ["UnitID", "MeasuredBy", "MeasurementDateTime", "Method"]
        extra_tags = ["AppliesTo"]
        delimiters = "(|["
        # map the csv fields to abcd terms:
        reformed_row = {}
        collection_dict = {}

        csv_data = []

        csv_data_p = list(create_csv_reader(csv_file))
        for dictrow in csv_data_p:
            reduced_row = {}
            extra_row = {}
            unit_dict = {}

            one_row_list = []

            row = self.map_fields_measurement(dictrow, abcd_mapping_measurement)
            for i in row.keys():
                reformed_row = {}
                collection_dict = {}

                if i in known_tags:
                    val = row[i]
                    reduced_row[i] = val
                    collection_dict.update(reduced_row)
                    if i == known_tags[0] and len(unit_dict) == 0:
                        unit_dict[i] = val
                        one_row_list.append(unit_dict)
                elif i in extra_tags:
                    val = row[i]
                    extra_row[i] = val
                else:
                    val = row[i]
                    split_result = xsplit(delimiters, str(i), 1)  # a list
                    reformed_row["Parameter"] = split_result[0].strip()
                    if len(extra_row):
                        reformed_row.update(extra_row)

                    reformed_row["LowerValue"] = val

                    if len(split_result) > 1:
                        reformed_row["UnitOfMeasurement"] = split_result[1].strip(" ()")

                    if is_float(val):
                        reformed_row["IsQuantitative"] = "true"
                    else:
                        reformed_row["IsQuantitative"] = "false"

                    collection_dict.update(reduced_row)
                    if reformed_row:
                        collection_dict.update(reformed_row)  # 9 fields
                    one_row_list.append(collection_dict)

            if not reformed_row:
                one_row_list.append(collection_dict)
            csv_data.append(one_row_list)

        return csv_data

    def read_and_map_multimedia_csv(self, csv_file):
        # map the csv fields to abcd terms:
        csv_data = []
        csv_data_p = list(create_csv_reader(csv_file))
        for rowdict in csv_data_p:
            row = self.map_fields_multimedia(rowdict, abcd_mapping_multimedia)
            csv_data.append(row)
            csv_data.sort(key=lambda row: row["UnitID"])

        return csv_data


    # now for specimen file only
    def convert_specimen_csv_data_to_xml(self, csv_data, units):
        # explicit procedure 'add_unit_data' to fill data records:
        length = len(csv_data)
        all_unit_ids = []
        for i in range(length):
            unid = csv_data[i]["UnitID"].strip()
            specimen_ataxer = specimen_csv_ataxer(self.io_handler, self.abcdns, row=i+1, unit_id=unid)
            all_unit_ids.append({"unit_id": unid, "row": i + 1})
            unit = add_unit(units, self.abcdns)
            specimen_ataxer.add_unit_data(unit, csv_data[i])

        self.ensure_unitids_uniqueness(all_unit_ids)


    def ensure_unitids_uniqueness(self, all_unit_ids):
        unit_id_rows = {}
        for unit_id in set([a["unit_id"] for a in all_unit_ids]): unit_id_rows[unit_id] = []
        for u in all_unit_ids: unit_id_rows[u["unit_id"]].append(str(u["row"]))
        
        doublets = [{"unit_id": u, "rows": unit_id_rows[u]} for u in unit_id_rows.keys() if len(unit_id_rows[u]) > 1]
        if doublets:
            doublets_list = str.join("\n", [u["unit_id"] + " in rows " + str.join(", ", u["rows"]) for u in doublets])
            self.io_handler.errorHandler.handle("Unit-ids must be unique among specimen.", { "message": "Repeating unit-ids: \n" + doublets_list, "file": "specimen" })


    def convert_measurement_csv_data_to_xml(self, csv_data, units):
        for item in csv_data:
            unit_id_node = False
            measurementsorfacts = None
            for mdict in item:
                single_dict = mdict  # dict contains UnitID
                if isinstance(single_dict, dict):
                    unit_id = single_dict.get("UnitID", None)
                    if unit_id and not unit_id_node:
                        unit = add_unit(units, self.abcdns)
                        add_unit_id(unit, self.abcdns, unit_id)
                        add_necc_nodes_measurements(unit, self.abcdns, unit_id)
                        unit_id_node = True

                    if self.contains_measurement(mdict):
                        if not measurementsorfacts:
                            measurementsorfacts = add_measurements_or_facts(unit, self.abcdns)

                        add_unit_data_measurement(
                            measurementsorfacts,
                            self.abcdns,
                            mdict,
                        )


    def contains_measurement(self, mdict):
        for entry in mdict:
            if entry != "UnitID":
                return True
        return False

    def convert_multimedia_csv_data_to_xml(self, csv_data, units):
        prev_UnitID = ""
        row = 2 # because row 1 == csv-header
        for item in csv_data:
            if item.get("UnitID", None):
                multimedia_ataxer = multimedia_csv_ataxer(self.io_handler, self.abcdns, row)
                curr_UnitID = item.get("UnitID")
                if prev_UnitID != curr_UnitID:
                    unit = add_unit(units, self.abcdns)
                    multimedia_ataxer.add_necc_nodes_multimedia(unit, curr_UnitID)
                    add_unit_id(unit, self.abcdns, item.get("UnitID"))
                    multimediaobjects = multimedia_ataxer.add_multimediaobjects(unit)
                    multimedia_ataxer.add_multimediaobject(multimediaobjects, item)
                else:
                    multimedia_ataxer.add_multimediaobject(multimediaobjects, item)

                prev_UnitID = curr_UnitID
            row += 1

    def finish_atax_xml(self):
        try:
            # unicode is important , we need a string to continue!
            return ET.tostring(self.root, encoding="unicode", method="xml")
        except:
            return None

    # End ATAXER


def analyze_file(upload_name):
    # meta_type condition is removed, maybe its possible to use it as an additional indicator?
    if "specimen" in upload_name:
        return "specimen"
    elif "measurement" in upload_name:
        return "measurement"
    elif "multimedia" in upload_name:
        return "multimedia"
    else:
        return ""


def parse_taxonomic_csv_specimen(io_handler, csv_file):
    return map_and_convert(io_handler, csv_file, 
                 lambda a, file: a.read_and_map_specimen_csv(file), 
                 lambda a, data, units: a.convert_specimen_csv_data_to_xml(data, units))


def parse_taxonomic_csv_measurement(io_handler, csv_file):
    return map_and_convert(io_handler, csv_file, 
                 lambda a, file: a.read_and_map_measurement_csv(file), 
                 lambda a, data, units: a.convert_measurement_csv_data_to_xml(data, units))


def parse_taxonomic_csv_multimedia(io_handler, csv_file):
    return map_and_convert(io_handler, csv_file, 
                 lambda ataxer, file: ataxer.read_and_map_multimedia_csv(file), 
                 lambda ataxer, data, units: ataxer.convert_multimedia_csv_data_to_xml(data, units))


def map_and_convert(io_handler, csv_file, mapping, conversion):
    try:
        ataxer = Ataxer(io_handler=io_handler)

        units = ataxer.create_atax_submission_base_xml()
        csv_data = mapping(ataxer, csv_file)
        conversion(ataxer, csv_data, units)

        return ataxer.finish_atax_xml()

    except Exception as e:
        io_handler.errorHandler.handle(e, traceback.format_exc())
        return None  # False, error

