

from abcd_converter_gfbio_org.handlers import Outputter


class ErrorHandlerWrapper(Outputter):
    def __init__(self, to_wrap):
        self.to_wrap = to_wrap
        self.error_encountered = False

    def handle(self, description, content):
        self.error_encountered = True
        self.to_wrap.handle(description, content)