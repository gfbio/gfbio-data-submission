# -*- coding: utf-8 -*-
import logging
import os

from .atax import (
    analyze_file,
    parse_taxonomic_csv_specimen,
    parse_taxonomic_csv_measurement,
    parse_taxonomic_csv_multimedia,
)

def atax_submission_parse_csv_upload_to_xml(file_path, io_handler):
    request_file_keys = ["specimen", "measurement", "multimedia"]

    io_handler.logHandler.handle("atax_submission_parse_csv_upload_to_xml_task was called", None)

    file_key = analyze_file(os.path.basename(file_path))

    if file_key in request_file_keys:
        match str(file_key):
            case "specimen":
                xml_data_as_string = convert_specimen_file(file_path, io_handler)
            case "measurement":
                xml_data_as_string = convert_measurement_file(file_path, io_handler)
            case "multimedia":
                xml_data_as_string = convert_multimedia_file(file_path, io_handler)
            case _:
                io_handler.logHandler.handle(
                    "tasks.py | atax_submission_parse_csv_upload_to_xml | "
                    'SubmissionUpload file"{0}" has no expected basename | '.format(file_path), "Filekey no match: " + file_key
                )
                return False

        # store xml data informations in auditabletextdata:
        if xml_data_as_string and len(xml_data_as_string) > 0:
            return xml_data_as_string

        else:
            io_handler.logHandler.handle("atax_submission_parse_csv_upload_to_xml_task. no transformed xml upload data.  | "
                " for {0},  return={1}  | ".format(str(file_key), "CANCELLED"), None)
            return False

    return True


def convert_specimen_file(file_path, io_handler):
    with open(file_path, "r", encoding="utf-8-sig") as data_file:
        specimen_xml = parse_taxonomic_csv_specimen(io_handler, data_file)
        io_handler.singleFileHandler.handle("specimen.xml", specimen_xml)
        return specimen_xml


def convert_measurement_file(file_path, io_handler):
    with open(file_path, "r", encoding="utf-8-sig") as data_file:
        measurement_xml = parse_taxonomic_csv_measurement(io_handler, data_file)
        io_handler.singleFileHandler.handle("measurement.xml", measurement_xml)
        return measurement_xml


def convert_multimedia_file(file_path, io_handler):
    with open(file_path, "r", encoding="utf-8-sig") as data_file:
        multimedia_xml = parse_taxonomic_csv_multimedia(io_handler, data_file)
        io_handler.singleFileHandler.handle("multimedia.xml", multimedia_xml)
        return multimedia_xml