import os


FILE_EXTENSIONS = {
    "image": ["jpg", "jpeg", "tiff", "png", "bmp", "pcx", "svg"],
    "video": [
        "webm", "mkv", "flv", "flv", "vob", "ogv, ogg", "drc", "gif", "gifv", "mng", "avi", 
        "mts", "m2ts", "ts", "mov, qt", "wmv", "yuv", "rm", "rmvb", "viv", "asf", "amv",
        "mp4", "m4v", "mpg", "mp2", "mpeg", "mpe", "mpv", "m2v", "m4v", 
        "svi", "3gp", "3g2", "mxf", "roq", "nsv", "flv", "f4v", "f4p", "f4a", "f4b"
    ],
    "sound": [
        "3gp", "aa", "aac", "aax", "act", "aiff", "alac", "amr", "ape", "au", "awb", "dss", "dvf",
        "flac", "gsm", "iklax", "ivs", "m4a", "m4b", "m4p", "mmf", "movpkg", "mp3", "mpc", "msv", "nmf",
        "ogg", "oga", "mogg", "opus", "ra, rm", "raw", "rf64", "sln", "tta",
        "voc", "vox", "wav", "wma", "wv", "webm", "8svx", "cda"
    ]
}


class MultimediaFileValidatorInterface:
    def validate(self, file_name, format, row):
        pass


class MultimediaFileValidator(MultimediaFileValidatorInterface):
    def __init__(self, io_handler, file_directory):
        self.io_handler = io_handler
        self.file_directory = file_directory

    def validate(self, file_name, format, row):
        if not file_name:
            self.io_handler.warning_handler.handle(f"File in row {row} has no name.", { "file": "multimedia", "row": row, "message": "File has no name"})
            return

        if not format:
            self.io_handler.warning_handler.handle(f"File in row {row} has no format.", { "file": "multimedia", "row": row, "message": "File has no format"})
        else:
            file_extension = file_name.rsplit(".")[1]
            if (format.lower() not in FILE_EXTENSIONS and format.lower() != file_extension.lower()) or (format.lower() in FILE_EXTENSIONS and file_extension.lower() not in FILE_EXTENSIONS[format.lower()]):
                msg = f"File extension '{file_extension}' of {file_name} may not match the format description '{format}'."
                self.io_handler.warning_handler.handle(msg, { "file": "multimedia", "row": row, "message": "Unrecognized file extension"})

        file_path = os.path.join(self.file_directory, file_name)
        if not os.path.isfile(file_path):
            msg = f"File {file_name} in row {row} is missing it's corresponding file '{file_path}'."
            self.io_handler.errorHandler.handle(msg, { "file": "multimedia", "row": row, "message": "File not found"})