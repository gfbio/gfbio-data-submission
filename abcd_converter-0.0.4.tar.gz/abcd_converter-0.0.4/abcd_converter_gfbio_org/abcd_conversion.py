from .handlers import InOutHandler

from .abcd_converter.error_handler_wrapper import ErrorHandlerWrapper
from .abcd_converter.atax_submission_parse_csv_upload_to_xml import convert_specimen_file, convert_measurement_file, convert_multimedia_file
from .abcd_converter.atax_submission_combine_xmls_to_one_structure import atax_submission_combine_xmls_to_one_structure_task
from .abcd_converter.atax_submission_validate_xml_upload import atax_submission_validate_auditable_atax_xml_task


def convert_csv_to_abcd(specimen_file, measurement_file, multimedia_file, io_handler = InOutHandler()):
   
    error_handler_wrapper = ErrorHandlerWrapper(io_handler.errorHandler)
    io_handler.errorHandler = error_handler_wrapper

    spec_xml = convert_specimen_file(specimen_file, io_handler)
    meas_xml = convert_measurement_file(measurement_file, io_handler)
    multi_xml = convert_multimedia_file(multimedia_file, io_handler)

    empty_results = [r for r in [
        "specimen file" if not spec_xml else None,
        "measurement file" if not meas_xml else None,
        "mulitmedia file" if not multi_xml else None
    ] if r]
    if empty_results:
        io_handler.errorHandler.handle("Parsing was not successfull, errors in: " + str.join(", ", empty_results), {})
        return None
        
    combi_xml = atax_submission_combine_xmls_to_one_structure_task(io_handler, spec_xml, meas_xml, multi_xml)
    io_handler.resultFileHandler.handle("Generation of abcd completed.", combi_xml)

    is_valid = atax_submission_validate_auditable_atax_xml_task(combi_xml, io_handler)
    if not error_handler_wrapper.error_encountered and is_valid:
        return combi_xml
    else:
        io_handler.errorHandler.handle("Process ran into (validation-)errors. Please check error-log for further information.", {})
        return None