import datetime
import os

from .file_validation import MultimediaFileValidator


class MyStruct:
    def __init__(self, **entries):
        self.__dict__.update(entries)


class DataProvider():
    def get_user_username(self):
        return "Put your name here"

    def get_user_email(self):
        return "Put your emailadress here"

    def get_created_date(self):
        return datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


class Outputter():
    def handle(self, description, content):
        pass


class ConsoleOutputter(Outputter):
    def __init__(self, verbose=False):
        self.verbose = verbose
        
    def handle(self, description, content):
        if self.verbose:
            print(description)
            print(content)


class ConsoleShortLogger(Outputter):
    def __init__(self, verbose=False, prefix = ""):
        self.verbose = verbose
        self.prefix = prefix
        
    def handle(self, description, content):
        print(self.prefix + description)
        if self.verbose:
            print(content)


class FileOutputter(Outputter):
    def __init__(self, out_path="./", default_name="out.txt"):
        if os.path.isdir(out_path):
            print(f"{out_path} is not a file")
            out_path = os.path.join(os.path.dirname(out_path), default_name)
        self.out_path = out_path
        
    def handle(self, description, content):
        out_file = self.out_path
        with open(out_file, 'w+', encoding="utf-8") as f:
            f.write(content)
        print(f"{description} - written to {out_file}")


class SingleFileOutputter(Outputter):
    def __init__(self, out_path="./", prefix="sf_"):
        if not os.path.isdir(out_path):
            print(f"{out_path} is not a directory")
            out_path = os.path.dirname(out_path)
            print(f"Using {out_path} instead")
        self.out_path = out_path
        self.prefix = prefix
        
    def handle(self, description, content):
        out_file = os.path.join(os.path.dirname(self.out_path), self.prefix + description)
        with open(out_file, 'w+', encoding="utf-8") as f:
            f.write(content)
        print(f"{description} - written to {out_file}")


class InOutHandler:
    def __init__(self, verbose=False, out_file="result.xml", file_directory="."):
        self.dataProvider = DataProvider()
        self.resultFileHandler = FileOutputter(out_path = out_file)
        self.warning_handler = ConsoleShortLogger(verbose, prefix = "Warning: ")
        self.errorHandler = ConsoleShortLogger(verbose, prefix = "Error: ")
        self.logHandler = ConsoleShortLogger(verbose)
        self.singleFileHandler = Outputter()
        self.multimedia_validator = MultimediaFileValidator(self, file_directory)